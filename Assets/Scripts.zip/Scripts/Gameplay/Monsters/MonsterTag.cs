// Assets/Scripts/Gameplay/Monsters/MonsterTag.cs
using UnityEngine;

public class MonsterTag : MonoBehaviour
{
    public MonsterDef def;
}
